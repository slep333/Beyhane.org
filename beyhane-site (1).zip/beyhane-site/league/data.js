// Edit these. Scores, wins/losses and rankings are calculated automatically.
window.PLAYERS=[
 {name:"Aylin",joined:2022,photo:""},
 {name:"Deniz",joined:2021,photo:""},
 {name:"Kerem",joined:2023,photo:""},
 {name:"Mira",joined:2024,photo:""}
];
// date: YYYY-MM-DD, length: minutes, sa/sb: score of player a / b
window.MATCHES=[
 {a:"Aylin",b:"Deniz",sa:12,sb:9,date:"2026-11-08",length:34},
 {a:"Kerem",b:"Mira",sa:7,sb:11,date:"2026-11-01",length:28},
 {a:"Deniz",b:"Kerem",sa:15,sb:10,date:"2026-10-20",length:41},
 {a:"Mira",b:"Aylin",sa:8,sb:8,date:"2026-10-05",length:30}
];
