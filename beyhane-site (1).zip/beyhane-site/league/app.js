const M=[...MATCHES].sort((x,y)=>y.date.localeCompare(x.date));
const st={};PLAYERS.forEach(p=>st[p.name]={...p,w:0,l:0,score:0});
M.forEach(m=>{const a=st[m.a],b=st[m.b];if(!a||!b)return;a.score+=m.sa;b.score+=m.sb;
 if(m.sa>m.sb){a.w++;b.l++}else if(m.sb>m.sa){b.w++;a.l++}});
const R=Object.values(st).sort((x,y)=>y.score-x.score);
const el=document.getElementById("content"),page=document.body.dataset.page;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
let h="";
if(page==="matches")h=`<h1>Matches</h1><ul class="list">`+M.map(m=>{
 const w=m.sa>m.sb?m.a:m.sb>m.sa?m.b:null;
 return `<li class="card row"><div class="grow"><div class="big">${esc(m.a)} ${m.sa} - ${m.sb} ${esc(m.b)}</div>
 <div class="mute">${esc(m.date)} &middot; ${m.length} min</div></div>
 <div>${w?`Winner: <span class="win">${esc(w)}</span>`:"Draw"}</div></li>`}).join("")+`</ul>`;
if(page==="players")h=`<h1>Players</h1><ul class="list">`+R.map(p=>`<li class="card row">
 ${p.photo?`<img class="avatar" src="${esc(p.photo)}" alt="${esc(p.name)}">`:`<div class="avatar">${esc(p.name[0])}</div>`}
 <div class="grow"><div class="big">${esc(p.name)}</div><div class="mute">Joined ${p.joined}</div></div>
 <div><span class="win">${p.score}</span> <span class="mute">all-time score</span></div></li>`).join("")+`</ul>`;
if(page==="scoreboard")h=`<h1>Scoreboard</h1><div class="card"><table><thead><tr><th>#</th><th>Player</th><th>W</th><th>L</th><th>W/L rate</th><th>Total score</th></tr></thead><tbody>`+
 R.map((p,i)=>`<tr><td>${i+1}</td><td>${esc(p.name)}</td><td>${p.w}</td><td>${p.l}</td><td>${p.w+p.l?Math.round(100*p.w/(p.w+p.l))+"%":"-"}</td><td>${p.score}</td></tr>`).join("")+`</tbody></table></div>`;
el.innerHTML=h;
